import os
import urllib.request
import cv2
import mediapipe as mp
import numpy as np

# 1. 自動檢查並下載最新版 MediaPipe Tasks 模型檔案
MODEL_PATH = 'hand_landmarker.task'
if not os.path.exists(MODEL_PATH):
    print("正在自動下載模型檔案...")
    url = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task'
    urllib.request.urlretrieve(url, MODEL_PATH)
    print("下載完成！")

# 2. 初始化 OpenCV 攝影機
cap = cv2.VideoCapture(0)

# 3. 使用最新版 MediaPipe Tasks API 初始化
BaseOptions = mp.tasks.BaseOptions
HandLandmarker = mp.tasks.vision.HandLandmarker
HandLandmarkerOptions = mp.tasks.vision.HandLandmarkerOptions
VisionRunningMode = mp.tasks.vision.RunningMode

options = HandLandmarkerOptions(
    base_options=BaseOptions(model_asset_path=MODEL_PATH),
    running_mode=VisionRunningMode.IMAGE,
    num_hands=2
)

tip_ids = [4, 8, 12, 16, 20]

# MediaPipe 標準手部骨架連線對應表
HAND_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),        # 姆指
    (0, 5), (5, 6), (6, 7), (7, 8),        # 食指
    (5, 9), (9, 10), (10, 11), (11, 12),  # 中指
    (9, 13), (13, 14), (14, 15), (15, 16),# 無名指
    (13, 17), (17, 18), (18, 19), (19, 20),# 小指
    (0, 17)                                # 手掌基底
]

def classify_gesture(landmarks):
    fingers = []
    # 大拇指判斷
    if landmarks[4].x > landmarks[3].x:
        fingers.append(1)
    else:
        fingers.append(0)
    # 其餘四指判斷
    for id_idx in range(1, 5):
        tip = tip_ids[id_idx]
        pip = tip - 2
        if landmarks[tip].y < landmarks[pip].y:
            fingers.append(1)
        else:
            fingers.append(0)
            
    total = sum(fingers)
    if total == 0:
        return "Rock"
    elif total == 5:
        return "Paper"
    elif fingers[1] == 1 and fingers[2] == 1 and total == 2:
        return "Scissors"
    return "Unknown"

def judge_winner(p1, p2):
    if p1 == "Unknown" or p2 == "Unknown":
        return "Waiting...", 0
    if p1 == p2:
        return "Tie!", 0
    elif (p1 == "Rock" and p2 == "Scissors") or \
         (p1 == "Paper" and p2 == "Rock") or \
         (p1 == "Scissors" and p2 == "Paper"):
        return "Player 1 Wins!", 1
    else:
        return "Player 2 Wins!", 2

score_p1 = 0
score_p2 = 0
frame_count = 0

with HandLandmarker.create_from_options(options) as landmarker:
    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break
        
        # 左右鏡像翻轉，操作更直覺
        frame = cv2.flip(frame, 1)
        h, w, _ = frame.shape
        
        # 轉換為 MediaPipe 影像格式
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        detection_result = landmarker.detect(mp_image)
        
        player_gestures = []
        
        if detection_result.hand_landmarks:
            for hand_landmarks in detection_result.hand_landmarks:
                points = [(int(lm.x * w), int(lm.y * h)) for lm in hand_landmarks]
                
                # A. 繪製標準骨架連線
                for connection in HAND_CONNECTIONS:
                    pt1 = points[connection[0]]
                    pt2 = points[connection[1]]
                    cv2.line(frame, pt1, pt2, (255, 255, 255), 2)
                
                # B. 繪製一般關節紅點
                for idx, pt in enumerate(points):
                    if idx != 8:  # 排除食指指尖
                        cv2.circle(frame, pt, 4, (0, 0, 255), -1)
                
                # C. 於食指指尖 (點 8) 繪製醒目的綠色亮點與白色外框特效
                index_tip_pt = points[8]
                cv2.circle(frame, index_tip_pt, 10, (0, 255, 0), -1)
                cv2.circle(frame, index_tip_pt, 12, (255, 255, 255), 2)
                
                # D. 手勢辨識
                gesture = classify_gesture(hand_landmarks)
                player_gestures.append(gesture)
                
                # E. 顯示各手辨識結果
                wrist = points[0]
                cv2.putText(frame, gesture, (wrist[0] - 30, wrist[1] - 20),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)

        # 雙人勝負與計分邏輯
        result_text = "Show 2 hands"
        winner = 0
        if len(player_gestures) == 2:
            result_text, winner = judge_winner(player_gestures[0], player_gestures[1])
            
            frame_count += 1
            if frame_count > 30:  # 冷卻機制避免分數暴衝
                if winner == 1:
                    score_p1 += 1
                elif winner == 2:
                    score_p2 += 1
                frame_count = 0
        else:
            frame_count = 0

        # 上方計分板與結果顯示區塊
        cv2.rectangle(frame, (20, 20), (w - 20, 95), (50, 50, 50), -1)
        cv2.putText(frame, f"P1 Score: {score_p1}   P2 Score: {score_p2}", (40, 52), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"Result: {result_text}", (40, 85), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

        cv2.imshow('Rock Paper Scissors Dual Player', frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()