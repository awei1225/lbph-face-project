import cv2
import mediapipe as mp
import numpy as np

cap = cv2.VideoCapture(0)
cap.set(3, 1280)
cap.set(4, 720)

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.8,
    min_tracking_confidence=0.8
)

paint_canvas = None
prev_x, prev_y = 0, 0
drawing_in_progress = False

while cap.isOpened():
    success, frame = cap.read()
    if not success:
        break
    
    frame = cv2.flip(frame, 1)
    h, w, c = frame.shape
    
    if paint_canvas is None:
        paint_canvas = np.zeros((h, w, c), dtype=np.uint8)
        
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(rgb_frame)
    
    status_text = "STATUS: IDLE"
    status_color = (0, 0, 255)
    
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            
            index_tip = hand_landmarks.landmark[8]
            index_mcp = hand_landmarks.landmark[5]
            
            x8, y8 = int(index_tip.x * w), int(index_tip.y * h)
            
            if index_tip.y < index_mcp.y:
                status_text = "STATUS: DRAWING"
                status_color = (0, 255, 0)
                
                cv2.circle(frame, (x8, y8), 10, (0, 255, 0), -1)
                cv2.circle(frame, (x8, y8), 12, (255, 255, 255), 2)
                
                if not drawing_in_progress:
                    prev_x, prev_y = x8, y8
                    drawing_in_progress = True
                    
                cv2.line(paint_canvas, (prev_x, prev_y), (x8, y8), (0, 0, 255), 8)
                prev_x, prev_y = x8, y8
            else:
                drawing_in_progress = False
    else:
        drawing_in_progress = False
            
    gray_canvas = cv2.cvtColor(paint_canvas, cv2.COLOR_BGR2GRAY)
    _, inv_canvas = cv2.threshold(gray_canvas, 20, 255, cv2.THRESH_BINARY_INV)
    inv_canvas = cv2.cvtColor(inv_canvas, cv2.COLOR_GRAY2BGR)
    
    frame = cv2.bitwise_and(frame, inv_canvas)
    frame = cv2.bitwise_or(frame, paint_canvas)
    
    cv2.putText(frame, status_text, (30, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, status_color, 3)
    cv2.putText(frame, "C: Clear | S: Save | Q: Quit", (30, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    cv2.imshow('Virtual Drawing Board', frame)
    
    key = cv2.waitKey(1) & 0xFF
    if key == ord('c'):
        paint_canvas = np.zeros((h, w, c), dtype=np.uint8)
    elif key == ord('s'):
        cv2.imwrite('my_drawing.png', paint_canvas)
        print("畫作已儲存")
    elif key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()