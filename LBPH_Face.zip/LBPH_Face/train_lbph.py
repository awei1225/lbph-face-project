import cv2
import numpy as np
import os
import json

data_dir = "data"
model_dir = "models"

if not os.path.exists(model_dir):
    os.makedirs(model_dir)

recognizer = cv2.face.LBPHFaceRecognizer_create()
faces = []
labels = []
label_dict = {}
current_id = 0

for user_name in os.listdir(data_dir):
    user_path = os.path.join(data_dir, user_name)
    if not os.path.isdir(user_path):
        continue

    label_dict[current_id] = user_name

    for img_name in os.listdir(user_path):
        img_path = os.path.join(user_path, img_name)
        gray_img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        if gray_img is None:
            continue

        faces.append(gray_img)
        labels.append(current_id)

    current_id += 1

print("正在訓練 LBPH 模型...")
recognizer.train(faces, np.array(labels))

recognizer.save(os.path.join(model_dir, "lbph_model.yml"))
with open(os.path.join(model_dir, "labels.json"), "w", encoding="utf-8") as f:
    json.dump(label_dict, f, ensure_ascii=False, indent=4)

print("模型訓練完成！已儲存至 models/ 資料夾內。")
