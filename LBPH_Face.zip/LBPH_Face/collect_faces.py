import cv2
import os

user_id = "student02"
output_dir = f"data/{user_id}"

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_alt.xml")
cap = cv2.VideoCapture(0)
count = 0

print("【提示】請面對鏡頭，按下鍵盤 's' 鍵拍照存檔，按下 'q' 鍵離開。")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

    cv2.imshow("Collect Faces", frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('s'):
        for (x, y, w, h) in faces:
            count += 1
            face_img = gray[y:y+h, x:x+w]
            file_path = os.path.join(output_dir, f"face_{count}.jpg")
            cv2.imwrite(file_path, face_img)
            print(f"已儲存: {file_path}")
    elif key == ord('q') or count >= 30:
        break

cap.release()
cv2.destroyAllWindows()
print("人臉樣本收集完成！")
